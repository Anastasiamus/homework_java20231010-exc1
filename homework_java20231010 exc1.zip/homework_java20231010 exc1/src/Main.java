import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Укажите длину в метрах: ");
        int a = input.nextInt();
        double b = 0.001;
        double c = 0.000621371;
        double d = 3.28084;
        double e = 0.7112;
        System.out.println(a*b);
        System.out.println(a*c);
        System.out.println(a*d);
        System.out.println(a*e);













        // 1 Дана длина в метрах.
        // Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
        // Выведите начальное и конвертированные значения на экран.











    }
}